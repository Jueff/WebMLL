# Datei-Version: 1.06 (2026-11-15) - headless_graph.py
# ----------------------------------------------------------------------------------------------
# Name:           headless_graph.py
# Path:           headless/headless_graph.py
# Version:        1.06
# Last Update:    2026-11-15
# Author:         Harold Linke
# Licence:        LGPL V2.1
# History of Change:
#   1.00  2026-10-28  Neu: Modell der Ketten fuer die grafische Ansicht (Stufe 1)
#   1.01  2026-10-28  LED Nr im Format Kanal-Nummer (1-5) wird gelesen; Makros mit Einzel-LEDs (C1-1, C2-1, ...) gehoeren in die Kette; mehrzeilige LEDs-Zellen
#   1.02  2026-10-30  Knoten haben icon_large (Symbol mit hoher Aufloesung), wenn es eines gibt
#   1.03  2026-11-01  Knoten haben tests (Testtasten der Zeile)
#   1.04  2026-11-12  build_model(..., all_rows): alle aktiven Zeilen in die Ketten, auch die ohne LEDs (in die Kette der nachfolgenden LED-Zeile, am Ende in die der letzten); Knoten haben noled
#   1.05  2026-11-13  Inaktive Zeilen (Spalte Aktiv leer) und mit dem Filter ausgeblendete Zeilen erscheinen in der Grafik nie, auch ohne 'Alle Zeilen' (Rueckmeldung des Excel-Entwicklers)
#   1.06  2026-11-15  Verteiler und Stecker (Spalten Verteiler-Nr. und Stecker-Nr.): Knoten tragen vt und plug, Luecken ohne Nummer innerhalb eines Verteilers erben den Stecker, model["vtinfo"] (Typ und Sicherung aus den ID-Zeilen darueber)
# ----------------------------------------------------------------------------------------------

"""Grafische Ansicht des Programm Generators, Stufe 1: das Modell der Ketten.

Aus den Zeilen eines Datenblatts (DCC, Selectrix, CAN, ...) werden Ketten gebildet: alle Zeilen mit LEDs eines LED Kanals, in der Reihenfolge der Tabelle.
Zeilen ohne LEDs (Sound, Logik, ...) gehoeren zu keiner Kette und stehen getrennt. Das Modell ist ein Ergebnis der Tabelle und wird nie getrennt gespeichert:
Nach jeder Aenderung der Tabelle wird es neu berechnet, damit Tabelle und Grafik immer uebereinstimmen. Es enthaelt keine Texte in einer Sprache (die setzt
_web/web_graph.py) und ist mit dem echten Blatt ohne Browser testbar.
Konzept: KONZEPT_Grafische_Ansicht.md"""
import logging
import re  # v1.01

logger = logging.getLogger(__name__)

SINGLE_RE = re.compile(r"^\^?\s*(C\d+(?:-\d+)?)$", re.I)          # Einzel-LEDs: C1-1, C2-3, C12 (eine Farbe eines WS2811, mit ^ am Anfang beginnt ein neues Modul)  # v1.01
LED_NR_RE = re.compile(r"^(\d+)-(\d+)$")                           # Anzeige 'Kanal-Nummer' in der Spalte LED Nr, wenn mehrere LED Kanaele benutzt werden (LEDNr_Display_Type 1)  # v1.01


def to_int(value, default=None):
    """Zahl aus einer Zelle (Text, Zahl oder leer) oder default"""
    try:
        text = str(value if value is not None else "").strip()
        if text == "":
            return default
        return int(float(text.replace(",", ".")))
    except (TypeError, ValueError):
        return default


def parse_leds(value) -> tuple:  # v1.01
    """Spalte LEDs -> (Anzahl voller LEDs, Einzel-LEDs als Text). Die Zelle enthaelt eine Zahl, bei Makros mit einzeln angesteuerten Farben 'C1-1', 'C2-3' ...
    und kann aus mehreren Zeilen bestehen (die Zahlen werden addiert, wie M30.CellLinesSum). Negative Zahlen (Next_LED(-n)) zaehlen nicht als LEDs."""
    leds, singles = 0, []  # v1.01
    for line in str(value if value is not None else "").replace("\r", "\n").split("\n"):  # v1.01
        text = line.strip()  # v1.01
        if not text:  # v1.01
            continue  # v1.01
        found = SINGLE_RE.match(text)  # v1.01
        if found:  # v1.01
            singles.append(found.group(1).upper())  # v1.01
            continue  # v1.01
        number = to_int(text)  # v1.01
        if number is not None and number > 0:  # v1.01
            leds += number  # v1.01
    return leds, " ".join(singles)  # v1.01


def parse_led_nr(value) -> tuple:  # v1.01
    """Spalte LED Nr -> (Kanal oder None, Nummer oder None): '5' -> (None, 5), '1-5' -> (1, 5) (Kanal-Nummer bei mehreren LED Kanaelen), sonst (None, None)"""  # v1.01
    text = str(value if value is not None else "").strip()  # v1.01
    found = LED_NR_RE.match(text)  # v1.01
    if found:  # v1.01
        return int(found.group(1)), int(found.group(2))  # v1.01
    return None, to_int(text)  # v1.01


def is_vt_number(text: str) -> bool:  # v1.06
    """Verteilernummer wie V01 (andere Texte in der Spalte sind Typangaben der ID-Zeilen)"""  # v1.06
    return len(text) > 1 and text[0] in "Vv" and text[1:].isdigit()  # v1.06


def fill_vt_gaps(nodes: list) -> None:  # v1.06
    """Zeilen ohne Verteilernummer zwischen Zeilen desselben Verteilers liegen im Rechteck dieses Verteilers und im Stecker davor (ein Rechteck von der ersten bis zur letzten Zeile)"""  # v1.06
    last = {}  # v1.06
    for i, n in enumerate(nodes):  # v1.06
        if n.get("vt"):  # v1.06
            last[n["vt"]] = i  # v1.06
    cur = None  # v1.06
    for i, n in enumerate(nodes):  # v1.06
        if n.get("vt"):  # v1.06
            cur = (n["vt"], n["plug"])  # v1.06
        elif cur is not None and last.get(cur[0], -1) > i:  # v1.06
            n["vt"], n["plug"], n["vt_gap"] = cur[0], cur[1], True  # v1.06
        elif cur is not None:  # v1.06
            cur = None  # v1.06


def macro_name(config: str) -> str:
    """Name des Makros aus dem Aufruf in der Spalte Config: 'House(#LED, ...)' -> 'House'"""
    text = str(config or "").strip()
    return text.split("(", 1)[0].strip() if "(" in text else text


# def build_model(ws, icons=None, display=None) -> dict:  # v1.02 (entfallen)
# def build_model(ws, icons=None, display=None, icon_large=None) -> dict:  # v1.03 (entfallen)
def _row_active(ws, sh, r, c_enable) -> bool:  # v1.04
    """Aktive Zeile wie beim Erzeugen des Programms (M06_Write_Header): Spalte Aktiv nicht leer und Zeile nicht ausgeblendet (Filter)"""  # v1.04
    if str(sh.get_cell_data(r, c_enable) or "").strip() == "":  # v1.04
        return False  # v1.04
    try:  # v1.04
        if ws.is_row_hidden(r):  # v1.04
            return False  # v1.04
    except Exception:                                                     # noqa: BLE001  # v1.04
        logger.debug("Zeile versteckt?", exc_info=True)  # v1.04
    return True  # v1.04


# def build_model(ws, icons=None, display=None, icon_large=None, tests=None) -> dict:  # v1.03 (entfallen)
def build_model(ws, icons=None, display=None, icon_large=None, tests=None, all_rows=False) -> dict:  # v1.04
    """Ketten und Knoten eines Datenblatts.

    icons: {(Zeile, Spalte): URL} (0-basiert, wie collect_icons); display: {(Zeile, Spalte): Text} (Get_Display_Cells, Namen in der gewaehlten Sprache).
    Ergebnis (JSON-faehig):
      {"sheet": Blattname, "ok": True, "count": Anzahl Knoten,
       "chains": [{"channel": Kanal, "led_count": Summe der LEDs, "nodes": [Knoten ...]}, ...],   # nach Kanal sortiert
       "other": [Knoten ohne LEDs ...], "all_rows": False oder True}
    Inaktive Zeilen (v1.05: in beiden Ansichten nie) fehlen immer. all_rows (v1.04): alle AKTIVEN Zeilen (Spalte Aktiv nicht leer, Zeile nicht ausgeblendet) stehen in der Reihenfolge der Tabelle in den Ketten, auch die ohne LEDs. Eine Zeile ohne LEDs
    kommt in die Kette der NACHFOLGENDEN Zeile mit LEDs (direkt vor sie: solche Makros gehoeren meist zu ihr); Zeilen hinter der letzten Zeile mit LEDs ans Ende der Kette dieser
    letzten Zeile; gibt es keine Zeile mit LEDs, bleiben sie in der Liste 'other'. Inaktive Zeilen fehlen in diesem Modus (auch die mit LEDs).
      Knoten: {"row": Zeile (0-basiert), "id": Zeilenkennung, "makro", "label", "descrip", "config", "icon" (URL oder ""),
               "leds" (volle LEDs), "single" (Einzel-LEDs wie 'C1-1' oder ''), "led_from", "led_to" (oder None), "channel"}"""
    import proggen.M02_Public as M02
    import proggen.M25_Columns as M25
    import proggen.M28_Diverse as M28
    model = {"sheet": str(getattr(ws, "Name", "")), "ok": False, "count": 0, "chains": [], "other": [], "all_rows": bool(all_rows)}  # v1.04
    try:
        if not M28.Is_Data_Sheet(ws):
            return model
        M25.Make_sure_that_Col_Variables_match(ws)
    except Exception:                                                     # noqa: BLE001
        logger.debug("Blatt ist kein Datenblatt", exc_info=True)
        return model
    sh = ws.tksheet
    icons = icons or {}
    display = display or {}
    c_cfg, c_nr, c_leds, c_ch = (int(M25.Config__Col) - 1, int(M25.LED_Nr__Col) - 1, int(M25.LEDs____Col) - 1, int(M25.LED_Cha_Col) - 1)
    c_name, c_desc, c_icon = int(M25.LanName_Col) - 1, int(M25.Descrip_Col) - 1, int(M25.MacIcon_Col) - 1
    first = int(M02.FirstDat_Row) - 1
    c_enable = int(M02.Enable_Col) - 1  # v1.04
    c_vt, c_plug = int(M25.Dist_Nr_Col) - 1, int(M25.Conn_Nr_Col) - 1  # v1.06
    vtinfo: dict = {}  # v1.06: Verteilernummer -> Text der ID-Zeile (Beschreibung, Typ, Sicherung)
    id_row = ""  # v1.06: zuletzt gesehene ID-Zeile (Verteiler ID n, Typ in der Spalte Verteiler-Nr., Sicherung in Stecker-Nr.)
    pending: list = []  # v1.04: Zeilen ohne LEDs, die auf die naechste Zeile mit LEDs warten (nur mit all_rows)
    last_channel = None  # v1.04: Kanal der letzten Zeile mit LEDs
    chains: dict = {}
    for r in range(max(first, 0), sh.get_total_rows()):
        config = str(sh.get_cell_data(r, c_cfg) or "").strip()
        vt_raw = str(sh.get_cell_data(r, c_vt) or "").strip()  # v1.06
        plug_raw = str(sh.get_cell_data(r, c_plug) or "").strip()  # v1.06
        if vt_raw and not is_vt_number(vt_raw):  # v1.06: ID-Zeile (z.B. IRM-60.1 / F1 (F1,25)): gehoert zum Verteiler, der darunter folgt (auch wenn die Zeile inaktiv ist)
            id_row = " · ".join(x for x in (str(sh.get_cell_data(r, c_desc) or "").strip(), vt_raw, plug_raw) if x)  # v1.06
        elif is_vt_number(vt_raw) and vt_raw.upper() not in vtinfo:  # v1.06
            vtinfo[vt_raw.upper()] = id_row  # v1.06
        if config == "":
            continue
        # if all_rows and not _row_active(ws, sh, r, c_enable):  # v1.04 (entfallen v1.05: gilt in beiden Ansichten)
        if not _row_active(ws, sh, r, c_enable):  # v1.05: inaktive und ausgeblendete Zeilen erscheinen nie in der Grafik
            continue  # v1.05
        # leds = to_int(sh.get_cell_data(r, c_leds), 0)  # v1.01 (entfallen)
        # led_from = to_int(sh.get_cell_data(r, c_nr))  # v1.01 (entfallen)
        # channel = to_int(sh.get_cell_data(r, c_ch), 0)  # v1.01 (entfallen)
        leds, single = parse_leds(sh.get_cell_data(r, c_leds))  # v1.01
        nr_channel, led_from = parse_led_nr(sh.get_cell_data(r, c_nr))  # v1.01
        channel = to_int(sh.get_cell_data(r, c_ch), nr_channel if nr_channel is not None else 0)  # v1.01
        in_chain = leds > 0 or single != ""                               # auch Makros mit Einzel-LEDs (C1-1 ...) belegen LEDs der Kette  # v1.01
        makro = macro_name(config)
        try:
            row_id = sh.row_id(r)
        except Exception:                                                 # noqa: BLE001
            row_id = None
        label = str(display.get((r, c_name)) or sh.get_cell_data(r, c_name) or "").strip() or makro
        node = {"row": r, "id": row_id, "makro": makro, "label": label, "descrip": str(sh.get_cell_data(r, c_desc) or "").strip(),
                # "config": config, "icon": icons.get((r, c_icon), ""), "leds": leds,  # v1.01 (entfallen)
                # "led_from": led_from if leds > 0 else None,  # v1.01 (entfallen)
                "config": config, "icon": icons.get((r, c_icon), ""), "leds": leds, "single": single,  # v1.01
                # "icon_large": (icon_large(icons.get((r, c_icon), "")) if icon_large and icons.get((r, c_icon), "") else ""),     # Gegenstueck mit hoher Aufloesung (icons_gross), sonst ""  # v1.03 (entfallen)
                "icon_large": (icon_large(icons.get((r, c_icon), "")) if icon_large and icons.get((r, c_icon), "") else ""),  # v1.03
                "tests": [dict(item) for item in ((tests or {}).get(r) or [])],                # Testtasten der Zeile (wie in der Tabelle): [{n: Name, c: Farbe, t: Text}]     # Gegenstueck mit hoher Aufloesung (icons_gross), sonst ""  # v1.03
                "led_from": led_from if in_chain else None,  # v1.01
                "led_to": (led_from + leds - 1) if (leds > 0 and led_from is not None) else None, "channel": channel}
        node["vt"] = vt_raw.upper() if is_vt_number(vt_raw) else ""  # v1.06
        node["plug"] = plug_raw if node["vt"] else ""  # v1.06
        node["noled"] = not in_chain  # v1.04: Zeile ohne LEDs (die Grafik zeichnet sie anders)
        # if leds > 0:  # v1.01 (entfallen)
        if in_chain:  # v1.01
            if pending:  # v1.04: Zeilen ohne LEDs davor gehoeren zu dieser Zeile: in ihre Kette, direkt vor sie
                for waiting in pending:  # v1.04
                    waiting["channel"] = channel  # v1.04
                chains.setdefault(channel, []).extend(pending)  # v1.04
                pending = []  # v1.04
            chains.setdefault(channel, []).append(node)
            last_channel = channel  # v1.04
        elif all_rows:  # v1.04
            pending.append(node)  # v1.04
        else:
            model["other"].append(node)
    if pending:  # v1.04: Zeilen hinter der letzten Zeile mit LEDs
        if last_channel is not None:  # v1.04
            for waiting in pending:  # v1.04
                waiting["channel"] = last_channel  # v1.04
            chains[last_channel].extend(pending)  # v1.04
        else:  # v1.04: keine Zeile mit LEDs im Blatt
            model["other"].extend(pending)  # v1.04
    for channel in sorted(chains):
        nodes = chains[channel]
        model["chains"].append({"channel": channel, "led_count": sum(n["leds"] for n in nodes), "nodes": nodes})
    for chain in model["chains"]:  # v1.06
        fill_vt_gaps(chain["nodes"])  # v1.06
    model["vtinfo"] = {k: v for k, v in vtinfo.items() if v}  # v1.06
    model["count"] = sum(len(c["nodes"]) for c in model["chains"]) + len(model["other"])
    model["ok"] = True
    return model


def find_node(model: dict, row: int):
    """Knoten zu einer Zeile (0-basiert) oder None"""
    for chain in model.get("chains", []):
        for node in chain["nodes"]:
            if node["row"] == row:
                return node
    for node in model.get("other", []):
        if node["row"] == row:
            return node
    return None
